###Programming Computer Vision with Python中译本整理代码
上面是Programming Computer Vision with Python书中整理出来的实例代码，代码对应中文主页[**Python计算机视觉编程**](http://yuanyong.org/pcvwithpython/)，部分代码仍在调试中。

![](http://willard-yuan.github.io/pcvwithpython/assets/images/cover.png)

注：该书代码是在windows下调试出来的，如果你要在linux下运行的话，请对代码做相应的调整。

###版权许可

本书采用“保持署名—非商用”创意共享4.0许可证。只要保持原作者署名和非商用，您可以自由地阅读、分享、修改本书。详细的法律条文请参见[创意共享](http://creativecommons.org/licenses/by-nc/4.0/)网站。
