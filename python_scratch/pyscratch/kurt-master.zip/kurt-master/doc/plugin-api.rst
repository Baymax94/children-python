Plugin API
==========

.. include:: warning.rst


Writing plugins
---------------

.. automodule:: kurt.plugin
    :no-members:


----



``KurtPlugin``
--------------

.. autoclass:: kurt.plugin.KurtPlugin
    :member-order: bysource


``Kurt``
--------

.. autoclass:: kurt.plugin.Kurt
    :member-order: bysource
