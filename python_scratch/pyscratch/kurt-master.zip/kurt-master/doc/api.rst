API
===

.. include:: warning.rst

This is the documentation for Kurt's interface, mostly the data structures for
storing and accessing the information contained in Scratch files.

-----

`kurt`

.. automodule:: kurt
    :undoc-members:
    :member-order: bysource


