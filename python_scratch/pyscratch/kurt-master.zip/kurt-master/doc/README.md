Kurt documentation


# Requirements for building

Requires "Armstrong" theme to be placed in `_themes/armstrong`

Download from:
https://github.com/armstrong/armstrong_sphinx.git

Then use `make html` to build the docs.
