.. Kurt documentation master file, created by
   sphinx-quickstart on Fri Mar 29 16:09:55 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Kurt's documentation!
================================

.. include:: warning.rst

Contents:

.. toctree::
   :maxdepth: 4

   changes-1.4
   api
   plugin-api



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

