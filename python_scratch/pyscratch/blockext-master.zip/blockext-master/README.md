blockext
========

Python module for writing Scratch 2.0 and Snap! extensions.

**DEPRECATED**:

> We were working on a Grand Unified extension framework for writing one extension in Python, that seamlessly worked with both Scratch and Snap!, patched over all the bugs in Scratch's HTTP, handled Unicode correctly, and even generated .xml/.sbe files for you.
>
> Sadly, the ST killed off HTTP extensions, and so blockext was never finished.
