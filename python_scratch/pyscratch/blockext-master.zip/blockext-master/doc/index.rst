.. Blockext documentation master file, created by
   sphinx-quickstart on Sat Jan 11 12:36:40 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Blockext's documentation!
====================================

Blockext is the easiest way to write extensions for `Scratch 2.0`_ and `Snap!`_
using the Python programming language.

Contents:

.. toctree::
   :maxdepth: 2

   tutorial



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`


.. _Scratch 2.0: http://scratch.mit.edu/
.. _Snap!: http://snap.berkeley.edu/
