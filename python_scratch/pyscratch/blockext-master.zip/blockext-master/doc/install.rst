Installation
============

Blockext is available on PyPI_, so you can install it using pip_::

    pip install blockext

Or alternatively using ``easy_install``::

    easy_install blockext 




.. _pip: http://pip-installer.org/


