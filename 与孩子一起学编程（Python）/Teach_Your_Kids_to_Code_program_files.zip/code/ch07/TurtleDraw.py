# TurtleDraw.py
import turtle
t = turtle.Pen()
t.speed(0)
turtle.onscreenclick(t.setpos)

