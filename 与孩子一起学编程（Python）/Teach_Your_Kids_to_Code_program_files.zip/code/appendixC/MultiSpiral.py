# MultiSpiral.py
import colorspiral
colorspiral.cspiral(5,50)
colorspiral.cspiral(4,50,100,100)

