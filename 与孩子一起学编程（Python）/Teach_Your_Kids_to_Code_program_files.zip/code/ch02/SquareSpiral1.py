# SquareSpiral1.py
import turtle
t=turtle.Pen()
for x in range(1,100):
    t.forward(x)
    t.left(90)

