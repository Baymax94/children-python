#CircleSpiral1.py
import turtle
t=turtle.Pen()
for x in range(100):
    t.circle(x)
    t.left(91)




