# YourName.py
name = input("What is your name?\n")
print("Hi, ", name)

