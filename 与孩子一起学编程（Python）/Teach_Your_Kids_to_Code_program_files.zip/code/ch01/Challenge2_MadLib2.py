adjective = input('Please enter an adjective: ')
noun = input('Please enter a noun: ')
verb = input('Please enter a verb ending in -ed: ')
animal = input('Please enter an animal: ')
print('Your MadLib:')
print('The', adjective, noun, verb, 'over the lazy brown', animal + '.')

