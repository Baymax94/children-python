# Rosette6.py
import turtle
t = turtle.Pen()
for x in range(6):
    t.circle(100)
    t.left(60)


