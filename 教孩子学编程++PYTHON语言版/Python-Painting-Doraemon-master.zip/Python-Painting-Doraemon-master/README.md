# Python-Painting-Doraemon-Pikachu

使用python3的turtle标准库绘制哆啦A梦、皮卡丘

![](https://raw.githubusercontent.com/PerpetualSmile/picture/master/Doraemon/Pikachu.gif)

---

![](https://raw.githubusercontent.com/PerpetualSmile/picture/master/Doraemon/Doraemon.gif)
