For information on installing libraries, see: http://www.arduino.cc/en/Guide/Libraries
FirmataPlusLBT (Bluetooth library) is compatible with 32u4 boards only (leonardo, mega).
