/*
 * Implementation is in EthernetClientStream.h to avoid linker issues.
 */
