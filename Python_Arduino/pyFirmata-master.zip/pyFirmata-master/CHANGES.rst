=======
Changes
=======

Version 1.1.x
=============

1.1.0 - 10/03/2019
------------------

- Nano board added
- Iterator daemon now exits properly

Version 1.0.x
=============

1.0.3 - 17/05/2015
------------------

- Pass ``timeout`` parameter on board trough to ``pyserial.Serial``.
- Added this change list.

1.0.2 - 17/01/2015
------------------

- Configure ``bumpversion``.
- Update to-do list.

1.0.1 - 17/01/2015
------------------

- Added Firmata's "Capability Query", that allows to auto setup a board. (This probably deserved a minor version bump...)
- Start distributing as wheels

1.0.0 - 04/01/2015
------------------

- Added Python 3 support
- Testing on Python 2.6 is dropped, but it might still work. Not actively supported though.
